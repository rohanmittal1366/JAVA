import java.io.*;
/*import java.io.File; 
import java.io.IOException; 
import java.io.RandomAccessFile; 
import java.lang.NumberFormatException; */
import java.util.Scanner;
class CRUDFile {
	File file;
	CRUDFile(String fname){
		try{
		file= new File(fname);
		if (!file.exists()) { 
                // Create a new file if not exists. 
                file.createNewFile(); 
            } 
		}catch(IOException e) {
    		System.out.println("Exception Occurred:");
	        e.printStackTrace();
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Usage: CRUDFile File_Name");
     	}
	}
	void AddDetails()
	{
		String data=new String();
		String rname=new String();
		
		Scanner sa=new Scanner(System.in);
		
		System.out.println("Enter Name:");
		String name=sa.next();
		System.out.println("Enter Age:");
		int age=sa.nextInt();
		System.out.println("Enter No:");
		int no=sa.nextInt();
		try{
		// Opening file in reading and write mode. 
        RandomAccessFile raf 
                = new RandomAccessFile(file, "rw"); 
        boolean found = false; 
		while (raf.getFilePointer() < raf.length()) { 
                  data = raf.readLine(); 
				  int index = data.indexOf('|'); 
				  rname=data.substring(0,index);
				  if(rname.equals(name)){
					found=true;
					break;
				  }
		}
		if(found==false){
			String d=name+"|"+age+"|"+no;
			raf.writeBytes(d);
			// To insert the next record in new line. 
            raf.writeBytes(System.lineSeparator()); 
			// Print the message 
            System.out.println(" Friend added. "); 
            // Closing the resources. 
            raf.close(); 
		}
		else { raf.close(); 
          System.out.println(" Input name already exits..."); 
        }
		}catch(IOException e) {
    		System.out.println("Add details Exception Occurred:");
	        e.printStackTrace();
		}
		
	}
	void UpdateDetails()
	{
		String data=new String();
		String rname=new String();
		int index;
		Scanner sa=new Scanner(System.in);
		
		System.out.println("Enter Name:");
		String name=sa.next();
		System.out.println("Enter new Age:");
		int age=sa.nextInt();
		System.out.println("Enter new No:");
		int no=sa.nextInt();
		try{
		// Opening file in reading and write mode. 
        RandomAccessFile raf 
                = new RandomAccessFile(file, "rw"); 
        boolean found = false; 
		while (raf.getFilePointer() < raf.length()) { 
                  //System.out.println(raf.getFilePointer());
				  data = raf.readLine(); 
				  //System.out.println(raf.getFilePointer());
				  index = data.indexOf('|'); 
				  rname=data.substring(0,index);
				  //System.out.println(rname);
				  if(rname.equals(name)){
					found=true;
					break;
				  }
		}
		if(found==true){
			String d=name+"|"+age+"|"+no;
			File tmpFile = new File("temp.txt"); 
            RandomAccessFile tmpraf 
                    = new RandomAccessFile(tmpFile, "rw");   
                // Set file pointer to start 
            raf.seek(0); 
			while (raf.getFilePointer() < raf.length()) { 
                // Reading the contact from the file 
                data = raf.readLine(); 
                index = data.indexOf('|'); 
                rname = data.substring(0, index); 
                if (rname.equals(name)) { 
					data = name+"|"+age+"|"+no;
                    }// Add this contact in the temporary file 
                    tmpraf.writeBytes(data); 
					// Add the line separator in the temporary file 
                    tmpraf.writeBytes(System.lineSeparator()); 
                } 
			raf.seek(0); 
            tmpraf.seek(0);
			while (tmpraf.getFilePointer() < tmpraf.length()) { 
                raf.writeBytes(tmpraf.readLine()); 
                raf.writeBytes(System.lineSeparator()); 
            }
			raf.setLength(tmpraf.length());
			tmpraf.close(); 
            raf.close(); 
            // Deleting the temporary file 
            tmpFile.delete(); 
			System.out.println(" Friend updated. ");
		}
		else { raf.close(); 
          System.out.println(" Input name does not exits..."); 
        }
		}catch(IOException e) {
    		System.out.println("Add details Exception Occurred:");
	        e.printStackTrace();
		}
		
	}
	void DeleteDetails()
	{
		String data=new String();
		String rname=new String();
		int index;
		Scanner sa=new Scanner(System.in);
		
		System.out.println("Enter Name:");
		String name=sa.next();
		try{
		// Opening file in reading and write mode. 
        RandomAccessFile raf 
                = new RandomAccessFile(file, "rw"); 
        boolean found = false; 
		while (raf.getFilePointer() < raf.length()) { 
                  //System.out.println(raf.getFilePointer());
				  data = raf.readLine(); 
				  //System.out.println(raf.getFilePointer());
				  index = data.indexOf('|'); 
				  rname=data.substring(0,index);
				  //System.out.println(rname);
				  if(rname.equals(name)){
					found=true;
					break;
				  }
		}
		if(found==true){
			//String d=name+"|"+age+"|"+no;
			File tmpFile = new File("temp.txt"); 
            RandomAccessFile tmpraf 
                    = new RandomAccessFile(tmpFile, "rw");   
                // Set file pointer to start 
            raf.seek(0); 
			while (raf.getFilePointer() < raf.length()) { 
                // Reading the contact from the file 
                data = raf.readLine(); 
                index = data.indexOf('|'); 
                rname = data.substring(0, index); 
                if (rname.equals(name)) { 
					continue;
                    }// Add this contact in the temporary file 
                    tmpraf.writeBytes(data); 
					// Add the line separator in the temporary file 
                    tmpraf.writeBytes(System.lineSeparator()); 
                } 
			raf.seek(0); 
            tmpraf.seek(0);
			while (tmpraf.getFilePointer() < tmpraf.length()) { 
                raf.writeBytes(tmpraf.readLine()); 
                raf.writeBytes(System.lineSeparator()); 
            }
			raf.setLength(tmpraf.length());
			tmpraf.close(); 
            raf.close(); 
            // Deleting the temporary file 
            tmpFile.delete(); 
			System.out.println(" Friend deleted. ");
		}
		else { raf.close(); 
          System.out.println(" Input name does not exits..."); 
        }
		}catch(IOException e) {
    		System.out.println("Add details Exception Occurred:");
	        e.printStackTrace();
		}
		
	}
	void Display(){
		String data=new String();		
		try{
		// Opening file in reading and write mode. 
        RandomAccessFile raf 
                = new RandomAccessFile(file, "rw"); 
		 System.out.println("File contents:");
		while (raf.getFilePointer() < raf.length()) {
				  data = raf.readLine(); 
				  int index=data.indexOf("|");
				  //String[] s = data.spilt("|");				  
				  String n=data.substring(0, index); 
				  System.out.print(n + " ");
				  String n1=data.substring(index+1); 
				  index=n1.indexOf("|");
				  n=n1.substring(0, index); 
				  System.out.print(n + " ");
				  n1=n1.substring(index+1); 
				  System.out.print(n1 + " ");
				  System.out.println();
		}	
		raf.close();		
		}catch(IOException e) {
    		System.out.println("Add details Exception Occurred:");
	        e.printStackTrace();
		}
	}
  public static void main(String args[]) {
	int ch; 
	Scanner sc=new Scanner(System.in);
	CRUDFile c=new CRUDFile(args[0]);
	do{
	System.out.println("Enter your choice:");
	System.out.println("1. Add Details");
	System.out.println("2. Delete Details");
	System.out.println("3. Update Details");
	System.out.println("4. Display Details");
	System.out.println("any other digit for exit");
	ch=sc.nextInt();
	switch(ch){
		case 1:
			c.AddDetails();
			break;
		case 2:
			c.DeleteDetails();
			break;
		case 3:
			c.UpdateDetails();
			break;
		case 4:
			c.Display();
			break;
	}
	}while(ch>=1 && ch<5);
  }
}