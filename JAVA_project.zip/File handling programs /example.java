import java.io.*;
import java.util.*;



class login 
{

static String name;

void login(String rname )
{
name = rname;
}


static void log ()  throws IOException
{

	Scanner input1 = new Scanner(System.in);
	String line ,n; 
	int index1=0;int choice2=0,index5=0,choice = 0;
try
{
do{


System.out.println("1.PERSONAL CHAT \n2.GROUP CHAT \n3.Display the message \n4.Quit ");
choice2 =input1.nextInt();
String S2 = input1.nextLine();



if(choice2 == 1){
	
	System.out.println("Enter the name of whom you want to send the message ");
	n=input1.nextLine();
	

	if(!(n.equals(name)))
	{


		
		File f = new File("../" + n);
		
		if(f.exists())
		{
			do
			{
			try{
		
			System.out.println("\n1. Write the message \n2. QUIT ");
			choice = input1.nextInt();
			String S = input1.nextLine();
			switch(choice)
			{

			case 1 :
			do
			{
				int jok=0;
				System.out.println("Enter the message you want to send else Enter quit  ");
				line = input1.nextLine();
			
				if(line.equals("quit"))
				jok=1;
			
				BufferedWriter bw = null;
	
				bw= new BufferedWriter(new FileWriter(new File("../" + n),true));
			
				if(jok!=1)	
				bw.write(name + " : " +  line + "\n" );
				bw.close();
		
			}while(!line.equals("quit"));
			break;	
	


			
		

			case 2 : break;
		
			
			default : System.out.println("INVALID INPUT");
			}
	
			}
			catch(InputMismatchException e )
			{
			System.out.println("EXCEPTION OCCURED : INCORRECT INPUT");
			break;
			}
	
			}while( choice!= 2);
	
		}
			
		

		else
		System.out.println("USER NOT FOUND");

	}
	else
	{
	System.out.println("YOU CAN NOT SEND THE MESSAGE TO YOURSELF ");
	}


}


else if(choice2 == 2){
	do
	{
	try{
	
	System.out.println("\n1. Write the message \n2. Display the message \n3. QUIT ");
	choice = input1.nextInt();
	String S = input1.nextLine();
		switch(choice)
		{
	
	
	case 1 :
		do
		{
		int jok=0;
		System.out.println("Enter the message you want to send else Enter quit  ");
		line = input1.nextLine();
	
		if(line.equals("quit"))
			jok=1;
			
			BufferedWriter bw = null;
	
			bw= new BufferedWriter(new FileWriter(new File("../groupchat"),true));
			
			if(jok!=1)	
			bw.write(name + " : " +  line + "\n" );
			bw.close();
		
		}while(!line.equals("quit"));
		break;
	
	case 2: 
			try{
			String data1=new String();
			File file = new File("../groupchat");
			
			Scanner rat = new Scanner(file);
			
			while(rat.hasNextLine())
				System.out.println(rat.nextLine());
			
			}
			catch(NoSuchElementException e)
			{ 
	    		System.out.println("LINE NOT FOUND ");  
			}
			break;
	
	case 3 : break;
		
	default : System.out.println("INVALID INPUT");
	
	
		}
	
	}
	catch(InputMismatchException e )
	{
	System.out.println("EXCEPTION OCCURED : INCORRECT INPUT");
	break;
	}
	}while( choice!= 3);
	
	}


else if(choice2 == 3)
{
	
			try{
			String data1=new String();
			File file = new File("../" + name);
			
			Scanner rat = new Scanner(file);
			
			while(rat.hasNextLine())
				System.out.println(rat.nextLine());
			
			}
			catch(NoSuchElementException e)
			{ 
	    		System.out.println("LINE NOT FOUND ");  
			}
			
	
}

	
}while(choice2 != 4);
}catch(InputMismatchException e ){
System.out.println("INVALID INPUT");
}
}
}






class example
{
   public static void main( String[] args ) throws IOException
   {


	String pas1 = new String() ;
	String data=new String();
	String rname=new String();
	String s1=new String();



	Scanner input = new Scanner(System.in);
	Scanner string = new Scanner(System.in);
	
      
	String id[] = new String[5];
	String pass[] = new String[5];
	int i=1;
	try {
	     File file = new File("../storepass");
	    
             boolean fvar = file.createNewFile();
	     if (fvar){
	          System.out.println("File has been created successfully");
	     }
	     else{
	          System.out.println("File already present ");
	     }
    	} catch (IOException e) 

	  {
    		System.out.println("Exception Occurred:");
	        e.printStackTrace();
	  }



	File file1 = new File("../storepass");
	System.out.println("Enter the password ");
	pass[0] = input.nextLine();

	Scanner fr = new Scanner(file1);
	s1 = fr.nextLine();


	label:
{
	while(true)
	{
		if( s1.equals(pass[0]))
		{
		System.out.println("PASSWORD IS CORRECT, WELCOME TO JAVA PROGRAM ");
		break label;

		}
		else
		System.out.println("PASSWORD IS INCORRECT ");


		System.out.println("Enter the password ");
		pass[0] = input.nextLine();


	}
} 


	int index=0,index2=0,index1=0;
	char ch;
	labal:
do
{
	System.out.println("Enter s for sign up \nEnter l for login \nEnter q to quit \n");
	ch = input.next().charAt(0);
	
	if(ch == 's' || ch == 'S' )
	{
		System.out.println("ENTER YOUR ID ");
		id[i]=string.nextLine();
	
		System.out.println("ENTER YOUR password ");
		pass[i]=string.nextLine();
		i++;
		
		try{
		
		
		
		BufferedWriter bw = null;
		bw= new BufferedWriter(new FileWriter(new File("../storepass"),true));
		bw.write("\n\n" + id[i-1] + "|");
		bw.write( pass[i-1] + "|");
		bw.close();
		bw= new BufferedWriter(new FileWriter(new File("../"+ id[i-1]  ),true));		
		}
		catch(IOException e) 
	{
    		System.out.println("Add details Exception Occurred:");
	        e.printStackTrace();
	}

	}
	
	else if( ch == 'l' || ch == 'L' )
	{
		
		Scanner sa=new Scanner(System.in);
		
		System.out.println("Enter Name:");
		String name=sa.next();
		System.out.println("Enter password:");
		String pas=sa.next();
		int jok=10;
		try
	{
		
		 File file = new File("../storepass");
		 
        RandomAccessFile raf  = new RandomAccessFile(file, "rw"); 
	
	label: while (raf.getFilePointer() < raf.length()) 
	{ 
			jok=1;
              	 data = raf.readLine(); 
		 index = data.indexOf('|');
		
			if(index == -1 )
			continue;
			
					
				  	rname=data.substring(0,index);
					index1 = data.lastIndexOf('|');
				  	pas1= data.substring(index+1,index1);
					
				 if(rname.equals(name))
				{

					if(pas.equals(pas1))
					{
						jok=0;
						System.out.println("YOUR PASSWORD IS CORRECT "); 
						login mybox = new login();				
						mybox.login(rname);

						login.log();					
						break label;  
					}
					else
						System.out.println("YOUR PASSWORD IS INCORRECT "); 
						break;
				}
				
				
	}
                            if(jok==1)
				{
				System.out.println("USERNAME IS INCORRECT ");
				
				}
	}

	catch(IOException e) 
	{
    		System.out.println("Add details Exception Occurred:");
	        e.printStackTrace();
	}

	}

	else if(ch == 'q' || ch == 'Q')
	{
	break labal ;

	}

	else
	{
	System.out.println(" YOU HAVE TYPE THE WRONG LETTER ");
	}

		System.out.println("Enter Q to Quit else Continue");
		ch = input.next().charAt(0);
		

}while( ch != 'q' || ch != 'Q');


System.out.println("THANKS FOR YOUR VISIT ");
}
}




