import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileDemo1 {
   public static void main(String[] args) {

       BufferedReader br = null;
       BufferedReader br2 = null;
       try{	
           br = new BufferedReader(new FileReader("C:\\myfile.txt"));		

           //One way of reading the file
	   System.out.println("Reading the file using readLine() method:");
	   String contentLine = br.readLine();
	   while (contentLine != null) {
	      System.out.println(contentLine);
	      contentLine = br.readLine();
	   }

	   br2 = new BufferedReader(new FileReader("C:\\myfile2.txt"));

	   //Second way of reading the file
	   System.out.println("Reading the file using read() method:");
	   int num=0;
	   char ch;
	   while((num=br2.read()) != -1)
	   {	
               ch=(char)num;
	       System.out.print(ch);
	   }

       } 
       catch (IOException ioe) 
       {
	   ioe.printStackTrace(); // It prints the stack trace of the Exception to System.err.  It's a very simple, but very useful tool for diagnosing an Exception. 
	   //It tells you what happened and where in the code this happened.
	   //It helps to trace the exception. For example you are writing some methods 
	   //in your program and one of your methods causes bug. 
	   //Then printstack will help you to identify which method causes the bug. 
	   //Stack will help like this:First your main method will be called and 
	   //inserted to stack, then the second method will be called and 
	   //inserted to the stack in LIFO order and if any error occurs somewhere 
	   //inside any method then this stack will help to identify that method.

       } 
       finally 
       {
	   try {
	      if (br != null)
		 br.close();
	      if (br2 != null)
		 br2.close();
	   } 
	   catch (IOException ioe) 
           {
		System.out.println("Error in closing the BufferedReader");
	   }
	}
   }
}